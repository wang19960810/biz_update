export * from "./component/data-view.d.ts"
export * from "./component/page-config.d.ts"
export * from "./component/menu.d.ts"
export * from "./component/dictCode.d.ts"
export * from "./component/page-button"


