import {defineStore, type StoreDefinition} from 'pinia'
import type {MenuItem} from "../../pages/transfer-menu/types"
import {filterNewlyAddedData} from "../../pages/transfer-menu/component/reder-menu.ts"
import {useServeStore} from '../serveStoreState.ts'
import {parentFirstSort, safeAwait} from "../../units/tool.ts"
import axios from "axios";

/**
 * 菜单
 * Represents the state of the menu store containing lists of menu items.
 * This interface defines the structure for maintaining different sets of menu items,
 * such as test and production environments. It provides a way to organize and manage
 * menu configurations separately based on their intended usage context.
 */
interface MenuStoreState {
    menuListDataTest: MenuItem[]
    menuListFlatDataTest: MenuItem[]
    menuListPro: MenuItem[]
    addedDataMenuList: MenuItem[]
    selectedMenu: MenuItem[]
}

export const useMenuStore: StoreDefinition<'menu', MenuStoreState> = defineStore('menu', {
    state: (): MenuStoreState => {
        return {

            menuListDataTest: [],  // 测试环境 菜单数据

            menuListFlatDataTest: [],  // 测试环境数据(扁平化的)

            menuListPro: [],  // 正式环境 菜单数据

            addedDataMenuList: [],  // 测试环境新增的 正式环境 的菜单

            selectedMenu: [], // 选择的菜单
        }
    },
    actions: {
        /**
         * 更新数据获取
         */
        async getUpdatedMenuList() {
            const [testMenu, proMenu] = await Promise.all([
                this.fetchMenu('test'),
                this.fetchMenu('prod'),
            ]);
            this.menuListDataTest = testMenu;
            this.menuListPro = proMenu;
            const {addedDataMenuList, testMenuListFlat} = filterNewlyAddedData(this.menuListDataTest, this.menuListPro);
            this.addedDataMenuList = addedDataMenuList
            this.menuListFlatDataTest = testMenuListFlat
        },


        /**
         * 通用菜单获取方法
         * @param env - 环境类型 ('test' 或 'prod')
         */
        async fetchMenu(env: 'test' | 'prod'): Promise<MenuItem[]> {
            const {url, Jwt} = useServeStore().getServeDetails(env);
            const response = await axios.get(`${url}/crm-mdm/v1/competences/competences/findByViewItemAndCurrentUser?viewItem=true&codeOrComment=`, {
                headers: {Jwt},
            });

            return response.data.data;
        },

        /**
         * 添加菜单到正式环境
         */
        async addMenuToPro() {
            const selectMenuSort = parentFirstSort(this.selectedMenu)
            const promiseArr = selectMenuSort.map(item => {
                return this.sendUpdateRequest(item, 'test')
            })
        },

        /**
         *
         * @param params
         * @param env
         */
        async sendUpdateRequest(params: MenuItem, env: 'test' | 'prod') {
            const {Jwt} = useServeStore().getServeDetails(env);
            const methods = params.id ? 'patch' : 'post';
            const headers = { Jwt }
            console.log(`${methods === 'post' ? '新增' : '更新'}菜单 ===> ${params.comment} ====> 开始`)
            const res = await safeAwait(axios[methods]("/crm-mdm/v1/competences/competences", params, {headers}), `${methods === 'post' ? '新增' : '更新'}菜单 ===> ${params.comment} ====> 失败`)
            console.log(`${methods === 'post' ? '新增' : '更新'}菜单 ===> ${params.comment} ====> 结束`)
            return res
        }

    }
})