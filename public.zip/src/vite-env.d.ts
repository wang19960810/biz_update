/// <reference types="vite/client" />
declare global {
    http: any
}
