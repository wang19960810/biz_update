/**
 * 接口请求基本参数
 */
export interface Serve {
    testUrl: string, // 测试域名
    testJwt: string, // 测试Jwt
    prodUrl: string, // 正式域名
    prodJwt: string, // 正式Jwt
}